.. :changelog:

History
-------

0.1.1 (2017-04-19)
++++++++++++++++++

* Update for Django 1.11 and Python 3

0.1.0 (2014-01-24)
++++++++++++++++++

* First release