# coding=utf-8

__version__ = '0.1.2.dev1'

default_app_config = 'easy_pdf.apps.EasyPDFConfig'
